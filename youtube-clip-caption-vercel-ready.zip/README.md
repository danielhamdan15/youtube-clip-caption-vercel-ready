# YouTube Clip Caption Tool

This is a simple React app that lets you extract clips from YouTube videos and display example captions.
